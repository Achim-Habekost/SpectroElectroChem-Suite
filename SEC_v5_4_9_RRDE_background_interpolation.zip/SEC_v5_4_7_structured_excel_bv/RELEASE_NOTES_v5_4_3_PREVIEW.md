# Version 5.4.3 Preview

## RRDE: vollständige Hintergrundmessung

- Eine separate N₂-/Hintergrundmessung kann nun als CSV- oder NOVA-Export ausgewählt werden.
- Bei dieser Methode werden **Disk- und Ringstrom** rotationsweise und punktweise von der O₂-Messung abgezogen.
- Die Funktion ist optional: Die Auswertung kann weiterhin ohne Untergrundkorrektur oder mit dem bisherigen Ring-Offset durchgeführt werden.
- Zur Vermeidung einer Vermischung von Hin- und Rückscan müssen Potentialraster, Punktzahl, Scanrichtung und Rotationen übereinstimmen.
- Die korrigierten Ströme werden für H₂O₂-Ausbeute, Elektronenzahl, Levich/Koutecký–Levich, Tafel und die Diagramme verwendet.
- Die ausgewertete CSV enthält zusätzlich die ursprünglichen Rohströme und die korrigierten Ströme.
