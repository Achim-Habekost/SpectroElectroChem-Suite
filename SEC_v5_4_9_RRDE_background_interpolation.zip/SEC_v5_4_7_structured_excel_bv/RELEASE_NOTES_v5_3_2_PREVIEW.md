# SpectroElectroChem Suite 5.3.2 Preview

## RRDE combined 3D HTML

- Replaced the vertically stacked ring-current axis title.
- Added horizontal, symmetric axis titles above the two current axes.
- Disk current is labelled in dark blue above the left axis.
- Ring current is labelled in dark red above the right axis.
- Preserved the interactive 3D view, ring scaling, tick labels and visibility controls.
