# SpectroElectroChem Suite 5.0 Beta 2.3

## RRDE user interface

- Restored the always-visible `Auswertung starten` button.
- Added a vertically scrollable RRDE settings area.
- The bottom action bar remains fixed while settings are scrolled.
- The result-folder button and progress indicator are always visible.
- Direct general CSV import from Beta 2.2 is retained.
- All existing processing, plotting and Excel export features are retained.
