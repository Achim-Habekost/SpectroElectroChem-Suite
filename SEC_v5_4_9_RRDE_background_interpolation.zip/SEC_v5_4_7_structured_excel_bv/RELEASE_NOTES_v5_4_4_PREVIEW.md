# Version 5.4.4 Preview

- Removed the import-format selector from the RRDE user interface.
- Removed all visible Metrohm NOVA-specific import controls.
- RRDE measurement and background files are now selected exclusively as CSV files.
- Added an in-program “CSV-Struktur …” information dialog.
- Renamed the import status display to “Dateistatus”.
- The selected CSV is checked immediately and detected rotation rates are displayed.
- N₂/background files use the same standard RRDE CSV structure as the O₂ measurement.
