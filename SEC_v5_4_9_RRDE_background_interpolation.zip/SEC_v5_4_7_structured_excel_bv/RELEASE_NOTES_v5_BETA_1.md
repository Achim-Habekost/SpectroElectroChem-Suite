# SpectroElectroChem Suite 5.0 Beta 1

## RRDE Analysis

- Import options limited to Metrohm NOVA and general CSV files.
- No automatic interpretation of NOVA exports.
- New manual column-assignment dialog with file preview.
- Potential, rotation, disk and ring columns must be confirmed before analysis.
- Existing smoothing, ring-background correction, 2D/3D visualization and
  Excel-report functions are retained.
- Ring-current axis title remains fixed beside the red secondary scale.
