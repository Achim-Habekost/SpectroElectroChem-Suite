# SpectroElectroChem Suite 5.0 Beta 2.2

## RRDE import

- General CSV files are imported directly without a verification or
  column-assignment dialog.
- The established CSV structure is used:
  first column = potential; subsequent columns = Disk/Ring pairs.
- Metrohm NOVA remains a separate import option with its existing assignment
  dialog until the NOVA workflow is specified in detail.
- All existing RRDE processing, plots and Excel exports are retained.
