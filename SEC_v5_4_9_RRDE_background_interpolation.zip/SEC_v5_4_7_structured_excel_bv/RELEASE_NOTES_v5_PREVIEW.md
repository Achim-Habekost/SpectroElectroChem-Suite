# SpectroElectroChem Suite 5.0 Preview 1

## Added
- Integrated **RRDE Analysis** module on the main dashboard.
- Automatic recognition of potential and Disk/Ring column pairs.
- Savitzky–Golay smoothing.
- Ring-current background compensation by potential-range mean or manual offset.
- Separate and combined Disk/Ring 2D plots.
- Separate and combined interactive 3D HTML plots.
- Excel report with raw, smoothed and corrected data and a secondary Ring-current axis.

## Architecture
The RRDE module is registered through the existing plugin registry and can be launched from the main window, File menu, or toolbar.


## Preview 2
- RRDE import limited to Metrohm NOVA exports and general CSV files.
- Ring-current axis title is anchored directly to the red 3D axis.


## Preview 3
- Fixed the combined 3D scene domain.
- Ring-current axis title is anchored directly beside the red axis and no longer shifts with the legend.
