# SpectroElectroChem Suite 5.1 Preview 2

- Separate Eingabefelder für das Levich-Potenzial E_L und das Koutecký–Levich-Potenzial E_KL.
- Levich verwendet ausschließlich die Diskströme bei E_L.
- Koutecký–Levich verwendet ausschließlich die Diskströme bei E_KL.
- Getrennte Plausibilitätsprüfung und lineare Interpolation beider Potenziale.
- Diagrammtitel, HTML und Excel-Bericht dokumentieren beide Potenziale getrennt.
