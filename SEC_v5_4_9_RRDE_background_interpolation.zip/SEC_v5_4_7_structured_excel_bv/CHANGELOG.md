# Changelog

## v4.0.0 — First Public Release

- First official public release of SpectroElectroChem Suite.
- Cleaned repository structure.
- Added `.gitignore` and `.gitattributes`.
- Removed Python cache and compiled files.
- Updated README for publication and user installation.
- Updated citation metadata.
- Added release notes.
- Raman/SERS voltammogram module includes waterfall vertical offset.
- Raman/SERS voltammogram module exports waterfall data to Excel:
  - `Waterfall_Shifted_Values`
  - `Waterfall_Unshifted_Values`
  - `Waterfall_Offsets`
- Included Raman spectrum analysis, SERS/Raman voltammograms, absorptovoltammograms and fluorovoltammograms.
- Included documentation and packaging templates for Windows builds.

## Earlier development versions

- Raman spectrum analysis.
- SERS/Raman voltammogram visualization.
- Absorpto-/fluorovoltammogram visualization.
- Baseline correction, smoothing and Excel/HTML/PDF export.
- Plugin-ready structure and central launcher architecture.

## v5.4.5 Preview
- Improved diffusion-limited plateau selection wording and diagnostics.
- Added plateau slope and relative slope to the Tafel Excel report.
- Introduced graded plateau-drift warnings.
- Clarified the scope of absolute cathodic disk currents in Levich/Koutecký–Levich calculations.

## v5.4.6 Preview
- Restored a clearly structured Tafel Excel Summary sheet.
- Added formatted sections for general settings, Tafel analysis, limiting-current analysis, and warnings.
- Added a compact limiting-current table with rotation rate, limiting current, drift, relative scatter, and plateau slope.
- Rounded rotation rates in the summary table for improved readability.
- Collected all quality warnings in a dedicated highlighted section.
