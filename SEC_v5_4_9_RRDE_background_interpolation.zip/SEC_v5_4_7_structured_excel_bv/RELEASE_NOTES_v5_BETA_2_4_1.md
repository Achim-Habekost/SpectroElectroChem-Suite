# SpectroElectroChem Suite 5.0 Beta 2.4.1

## RRDE fixes

- The ring-current axis title in the combined 3D HTML is now a true 3D
  text element anchored directly beside the red ring-current axis.
- It therefore moves together with the axis when the plot is rotated.
- The combined Excel diagram is now constructed from two combined chart
  objects: Disk on the primary left axis and Ring exclusively on the
  secondary right axis.
- All other plots and exports remain unchanged.
