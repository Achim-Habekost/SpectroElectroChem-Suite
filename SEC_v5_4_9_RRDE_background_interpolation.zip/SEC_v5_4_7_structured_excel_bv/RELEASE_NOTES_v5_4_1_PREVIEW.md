# v5.4.1 Preview

Tafel-analysis enhancements:

- optional **Use Koutecký–Levich corrected current** using `1/I = 1/I_k + 1/I_L`
- user-defined limiting-current potential for each rotation curve
- fit parameters and R² shown in a compact plot table
- mean absolute Tafel slope ± standard deviation
- enhanced Plotly hover information
- extended Excel summary and per-rotation data sheets
