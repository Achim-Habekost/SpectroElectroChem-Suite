# SpectroElectroChem Suite 5.0 Beta 2.4.2

- Excel combined chart now uses one scatter chart with Ring series explicitly assigned to y2_axis.
- Verified that the generated chart XML contains a distinct secondary axis system.
- The combined 3D HTML positions each character of the Ring-current title at its own 3D coordinate directly beside the red axis.
