# SpectroElectroChem Suite 5.3.3 Preview

## 3D axis-title refinement

- Disk and ring current titles are now anchored to the corresponding 3D-axis endpoints.
- The titles move with the Plotly scene during rotation and zooming instead of floating at fixed browser positions.
- The horizontal, color-coded presentation is retained.
