# SpectroElectroChem Suite v5.4.6 Preview

## Tafel Excel report

The Tafel `Summary` worksheet has been reorganized into clearly formatted sections:

- General settings
- Tafel analysis
- Limiting-current analysis
- Warnings

The limiting-current diagnostics are now presented as a compact table containing rotation rate, mean limiting current, drift, relative scatter, and plateau slope. Warnings are grouped at the end of the worksheet and highlighted for readability.
