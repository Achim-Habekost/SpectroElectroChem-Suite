# SpectroElectroChem Suite 5.3 Preview

## RRDE: Hydrogen peroxide analysis

This preview adds optional RRDE calculations for:

- hydrogen peroxide yield as a function of potential;
- number of electrons, n(E), as a function of potential;
- manufacturer-specified or experimental/manual collection efficiency;
- use of the existing ring-current background correction before calculation;
- English PNG, interactive HTML and Excel exports;
- plausibility warnings for H2O2 yields outside 0–100% and n values outside 2–4.

The German user interface is retained. Exported analysis labels are in English.

## v5.3.1 Preview

- Manual potential range for H2O2 yield and n(E).
- Values outside the selected range are exported as blank/NaN and are not plotted.
- New German GUI button **„Aktuellen Plotbereich verwenden …“**.
- The button opens an interactive disk-current plot with zoom and pan tools; the visible x-axis range can be transferred directly to the evaluation fields.
- The selected potential range is documented in the English Excel summary.
