# Version 5.4.2 preview

- Scientifically reviewed Tafel and mass-transport correction.
- Limiting current is now estimated from a user-selected plateau range (median), not one point.
- Added diagnostics for plateau scatter/drift and |I|/|I_L| sensitivity.
- Expanded Excel export with kinetic-current and correction diagnostics.
- Clarified terminology: kinetic current (mass-transport corrected).
