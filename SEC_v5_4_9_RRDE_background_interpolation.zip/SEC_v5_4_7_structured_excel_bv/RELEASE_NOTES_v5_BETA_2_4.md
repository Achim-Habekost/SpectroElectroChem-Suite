# SpectroElectroChem Suite 5.0 Beta 2.4

## RRDE interface

- Large green `AUSWERTUNG STARTEN` button directly below the input section.
- F5 remains available as a keyboard shortcut.
- Start controls are disabled while an analysis is running.
- Ring-current axis title moved directly beside the red secondary axis.
- Legend moved above the 3D scene.
- All existing RRDE processing and export functions are retained.
