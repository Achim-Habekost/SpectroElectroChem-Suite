# SpectroElectroChem Suite 5.0 Beta 2

## RRDE import
- Metrohm NOVA files open with a compact proposal table.
- Potential, rotations and sequential disk/ring pairs are shown before import.
- The proposal is never used without explicit confirmation.
- Exceptional files can be edited in the detailed manual assignment dialog.
- General CSV files continue to use manual assignment.

## Visualization
- The combined 3D scene uses a wider fixed domain.
- The legend is horizontal above the scene.
- The vertical ring-current title is fixed immediately beside the red secondary scale.
