# SpectroElectroChem Suite v5.4.5 Preview

## Tafel / mass-transport correction

- Clearer GUI wording for the potential range used to determine the diffusion-limited current I_L.
- Separate “From” and “To” fields below the explanatory label.
- Plateau diagnostics now include the median limiting current, relative scatter, endpoint drift, linear plateau slope (A V⁻¹), and relative plateau slope (% V⁻¹).
- Drift warnings are graded: 3–8 % is described as slight drift; values above 8 % indicate that the range may not be fully diffusion-limited.
- Warning text now recommends checking a range with a more constant limiting current instead of declaring the complete analysis invalid.

## Levich / Koutecký–Levich

- The absolute-current checkbox now explicitly states that it applies to Levich/Koutecký–Levich calculations.
- The accompanying note explains that disk currents are interpolated independently at the selected Levich and Koutecký–Levich potentials.
