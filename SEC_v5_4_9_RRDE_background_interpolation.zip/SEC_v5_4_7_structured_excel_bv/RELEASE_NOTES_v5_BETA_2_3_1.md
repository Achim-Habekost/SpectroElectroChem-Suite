# SpectroElectroChem Suite 5.0 Beta 2.3.1

## Hotfix

- Fixed five incorrectly named Tkinter variables in the RRDE background-
  compensation controls.
- RRDE Analysis now opens normally again.
- The fixed bottom action bar and scrollable settings area from Beta 2.3
  are retained.
