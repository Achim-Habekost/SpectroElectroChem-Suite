# SpectroElectroChem Suite 5.1 Preview

## Neue RRDE-Funktion

- Optionale Levich- und Koutecký–Levich-Auswertung bei einem frei wählbaren Potential.
- Eingaben: Elektrodenfläche, Konzentration, kinematische Viskosität und Potential.
- Modus 1: Diffusionskoeffizient D aus vorgegebener Elektronenzahl n.
- Modus 2: Elektronenzahl n aus vorgegebenem Diffusionskoeffizienten D.
- Lineare Interpolation des Diskstroms am gewählten Potential.
- Ausgabe als PNG, interaktives HTML und Excel-Bericht.
- Anzeige von Steigung, Achsenabschnitt, R², D bzw. n sowie kinetischem Strom I_k.
