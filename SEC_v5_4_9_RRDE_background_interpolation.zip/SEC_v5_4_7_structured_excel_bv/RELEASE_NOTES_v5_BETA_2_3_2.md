# SpectroElectroChem Suite 5.0 Beta 2.3.2

## RRDE hotfix

- Corrected the three background-compensation entry widget names.
- Corrected the range-background method identifier to `range_mean`.
- RRDE Analysis window was instantiated successfully in a GUI smoke test.
- The fixed bottom action bar and direct CSV import remain unchanged.
