import numpy as np
import pytest

from spectroelectrochem_suite.modules.rrde_analysis import (
    RRDEData,
    subtract_rrde_background_measurement,
)


def make_data(potential, rotations, disk, ring):
    return RRDEData(
        potential=np.asarray(potential, dtype=float),
        rotations=list(rotations),
        disk=[np.asarray(v, dtype=float) for v in disk],
        ring=[np.asarray(v, dtype=float) for v in ring],
        potential_label="Potential / V",
    )


def test_complete_background_measurement_corrects_disk_and_ring_by_rotation():
    sample = make_data(
        [-1.0, -0.5, 0.0],
        [500.0, 1000.0],
        [[-10, -5, 0], [-20, -10, 0]],
        [[2, 1, 0], [4, 2, 0]],
    )
    # Background rotations deliberately in reverse order.
    background = make_data(
        [-1.0, -0.5, 0.0],
        [1000.0, 500.0],
        [[-2, -1, 0], [-1, -0.5, 0]],
        [[0.4, 0.2, 0], [0.2, 0.1, 0]],
    )

    disk, ring = subtract_rrde_background_measurement(sample, background)

    assert np.allclose(disk[0], [-9, -4.5, 0])
    assert np.allclose(ring[0], [1.8, 0.9, 0])
    assert np.allclose(disk[1], [-18, -9, 0])
    assert np.allclose(ring[1], [3.6, 1.8, 0])


def test_background_measurement_interpolates_slightly_different_potential_grid():
    sample = make_data([0.8, 0.5, 0.2], [500.0], [[10, 10, 10]], [[5, 5, 5]])
    background = make_data([0.81, 0.49, 0.19], [500.0], [[0.81, 0.49, 0.19]], [[1.62, 0.98, 0.38]])

    disk, ring = subtract_rrde_background_measurement(sample, background)

    assert np.allclose(disk[0], [9.2, 9.5, 9.8])
    assert np.allclose(ring[0], [3.4, 4.0, 4.6])


def test_background_measurement_rejects_opposite_scan_direction():
    sample = make_data([0.8, 0.5, 0.2], [500.0], [[1, 2, 3]], [[1, 2, 3]])
    background = make_data([0.19, 0.49, 0.81], [500.0], [[0, 0, 0]], [[0, 0, 0]])
    with pytest.raises(ValueError, match="Scanrichtung"):
        subtract_rrde_background_measurement(sample, background)
