import numpy as np

from spectroelectrochem_suite.modules.rrde_analysis import (
    calculate_equilibrium_potential,
    calculate_tafel_analysis,
)


def test_orr_equilibrium_potential_at_ph13_vs_agagcl():
    result = calculate_equilibrium_potential(
        "Oxygen reduction (ORR)", "Ag/AgCl (3 M KCl)", 13.0, 25.0
    )
    assert np.isclose(result["equilibrium_vs_rhe_v"], 1.229, atol=1e-12)
    assert np.isclose(result["equilibrium_vs_she_v"], 1.229 - 0.059159 * 13, atol=2e-4)
    assert np.isclose(
        result["equilibrium_vs_reference_v"],
        result["equilibrium_vs_she_v"] - 0.210,
        atol=1e-12,
    )


def test_tafel_fit_recovers_known_slope():
    potential = np.linspace(-0.20, 0.20, 101)
    e_eq = 0.05
    eta = potential - e_eq
    expected_slope = -0.120  # V per decade
    intercept = -0.03
    log_i = (eta - intercept) / expected_slope
    current = -10 ** log_i
    result = calculate_tafel_analysis(
        potential,
        [1600.0],
        [current],
        -0.10,
        0.10,
        e_eq,
        use_current_density=False,
    )
    curve = result["curves"][0]
    assert np.isclose(curve["slope_v_per_decade"], expected_slope, atol=1e-10)
    assert np.isclose(curve["r2"], 1.0, atol=1e-12)
    assert curve["n_points"] > 3


def test_tafel_requires_positive_area_for_current_density():
    potential = np.linspace(-0.1, 0.1, 11)
    current = -np.linspace(1e-4, 1e-3, 11)
    try:
        calculate_tafel_analysis(
            potential, [1000], [current], -0.1, 0.1, 0.0,
            use_current_density=True, area_cm2=0.0,
        )
    except ValueError as exc:
        assert "Elektrodenfläche" in str(exc)
    else:
        raise AssertionError("Expected ValueError")


def test_tafel_kl_correction_recovers_kinetic_current():
    potential = np.linspace(-0.8, -0.4, 81)
    e_eq = 0.2
    eta = potential - e_eq
    slope = -0.120
    intercept = -1.16
    kinetic = -10 ** ((eta - intercept) / slope)
    limiting = -0.02
    measured = kinetic * limiting / (kinetic + limiting)
    result = calculate_tafel_analysis(
        potential, [1000.0], [measured], -0.7, -0.5, e_eq,
        use_current_density=False,
        use_kl_corrected_current=True,
        limiting_current_from_v=-0.80,
        limiting_current_to_v=-0.76,
    )
    curve = result["curves"][0]
    assert result["use_kl_corrected_current"] is True
    assert np.isfinite(curve["limiting_current_a"])
    assert curve["r2"] > 0.99
    assert np.isclose(result["mean_absolute_slope_mv_per_decade"], abs(slope) * 1000, rtol=0.08)


def test_tafel_summary_statistics():
    potential = np.linspace(-0.2, 0.2, 101)
    e_eq = 0.0
    currents = []
    for slope in (-0.10, -0.12):
        eta = potential - e_eq
        currents.append(-10 ** ((eta + 0.03) / slope))
    result = calculate_tafel_analysis(
        potential, [1000, 2000], currents, -0.1, 0.1, e_eq,
        use_current_density=False,
    )
    assert result["n_fitted_curves"] == 2
    assert np.isclose(result["mean_absolute_slope_mv_per_decade"], 110.0, atol=1e-8)
    assert result["std_absolute_slope_mv_per_decade"] > 0



def test_tafel_kl_range_uses_plateau_median_and_exports_diagnostics():
    potential = np.linspace(-1.0, -0.4, 301)
    e_eq = 0.2
    slope = -0.120
    intercept = -1.16
    eta = potential - e_eq
    kinetic = -10 ** ((eta - intercept) / slope)
    true_limiting = -0.02
    measured = kinetic * true_limiting / (kinetic + true_limiting)
    result = calculate_tafel_analysis(
        potential, [1600.0], [measured], -0.70, -0.55, e_eq,
        use_current_density=False,
        use_kl_corrected_current=True,
        limiting_current_from_v=-1.00,
        limiting_current_to_v=-0.95,
    )
    curve = result["curves"][0]
    assert result["limiting_current_range_v"] == (-1.0, -0.95)
    assert curve["limiting_current_a"] < 0
    assert 0 <= curve["median_transport_fraction"] < 1
    assert np.isfinite(curve["limiting_plateau_drift_pct"])


def test_tafel_slope_is_independent_of_equilibrium_potential_offset():
    potential = np.linspace(-0.7, -0.5, 101)
    slope = -0.120
    eta = potential - 0.2
    current = -10 ** ((eta + 0.03) / slope)
    a = calculate_tafel_analysis(potential, [1000], [current], -0.68, -0.52, 0.2,
                                 use_current_density=False)
    b = calculate_tafel_analysis(potential, [1000], [current], -0.68, -0.52, 0.4,
                                 use_current_density=False)
    assert np.isclose(a["curves"][0]["slope_v_per_decade"],
                      b["curves"][0]["slope_v_per_decade"], atol=1e-12)


def test_plateau_slope_and_tiered_drift_warning_are_reported():
    potential = np.linspace(-1.7, -0.4, 131)
    # Deliberately sloping diffusion-limited region around -1.6 to -1.2 V.
    current = -1.0e-3 + 2.5e-4 * (potential + 1.45)
    result = calculate_tafel_analysis(
        potential, [1000], [current], -0.9, -0.7, 0.2,
        False, None, True,
        limiting_current_from_v=-1.6,
        limiting_current_to_v=-1.2,
    )
    curve = result["curves"][0]
    assert np.isfinite(curve["limiting_plateau_slope_a_per_v"])
    assert np.isfinite(curve["limiting_plateau_relative_slope_pct_per_v"])
    assert curve["limiting_plateau_relative_slope_pct_per_v"] > 0
    assert any("Drift" in warning for warning in result["warnings"])
