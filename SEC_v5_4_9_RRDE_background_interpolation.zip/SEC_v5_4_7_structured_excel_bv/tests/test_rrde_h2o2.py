import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import numpy as np

from spectroelectrochem_suite.modules.rrde_analysis import calculate_h2o2_analysis


def test_h2o2_and_n_formula():
    potential = np.array([0.0, -0.1, -0.2])
    disk = [np.full(3, -1.0e-3)]
    ring = [np.full(3, 10.0e-6)]
    result = calculate_h2o2_analysis(potential, [2000], disk, ring, 0.25)
    curve = result["curves"][0]
    expected_h2o2 = 200.0 * 40.0e-6 / (1.0e-3 + 40.0e-6)
    expected_n = 4.0 * 1.0e-3 / (1.0e-3 + 40.0e-6)
    assert np.allclose(curve["h2o2_yield_percent"], expected_h2o2)
    assert np.allclose(curve["n_electrons"], expected_n)


def test_collection_efficiency_validation():
    potential = np.array([0.0, -0.1, -0.2])
    disk = [np.full(3, -1.0e-3)]
    ring = [np.full(3, 10.0e-6)]
    try:
        calculate_h2o2_analysis(potential, [2000], disk, ring, 0.0)
    except ValueError:
        pass
    else:
        raise AssertionError("Expected ValueError for N=0")


def test_h2o2_potential_range_masks_values():
    potential = np.array([-1.0, -0.5, 0.0, 0.5])
    result = calculate_h2o2_analysis(
        potential, [1000.0],
        [np.full(4, -1.0e-3)],
        [np.full(4, 10.0e-6)],
        0.25, -0.6, 0.1,
    )
    curve = result["curves"][0]
    assert np.isnan(curve["n_electrons"][0])
    assert np.isfinite(curve["n_electrons"][1])
    assert np.isfinite(curve["n_electrons"][2])
    assert np.isnan(curve["n_electrons"][3])
    assert result["potential_range"] == (-0.6, 0.1)
