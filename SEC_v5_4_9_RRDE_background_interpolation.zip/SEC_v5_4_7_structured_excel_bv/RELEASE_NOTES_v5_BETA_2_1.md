# SpectroElectroChem Suite 5.0 Beta 2.1

## Simplified Metrohm NOVA import

- First column is treated as potential.
- Remaining columns are read strictly as Disk/Ring pairs.
- Columns 2, 4, 6, ... are Disk currents.
- Columns 3, 5, 7, ... are Ring currents.
- Rotation speed is read from each Disk-column header.
- Empty/Unnamed Ring headers are displayed using the corresponding rotation.
- The normal workflow requires only a short review and one click on Import.
- Manual column assignment remains available only for exceptional files.
- Original source headers and measured values are not modified.
