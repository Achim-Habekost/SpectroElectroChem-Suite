# SpectroElectroChem Suite 5.0 Beta 2.3.3

## RRDE start controls

- Added a second, immediately visible `Auswertung starten` button directly
  below the input/output section.
- Retained the fixed bottom action bar.
- Reduced the initial RRDE window height for smaller displays.
- Added F5 as a keyboard shortcut to start the analysis.
