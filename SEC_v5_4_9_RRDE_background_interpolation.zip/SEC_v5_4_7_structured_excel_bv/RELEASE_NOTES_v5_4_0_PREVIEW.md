# SpectroElectroChem Suite 5.4.0 Preview

## New: Tafel analysis for aqueous systems

- Optional Tafel analysis integrated into the RRDE module.
- Required reaction, reference electrode and pH fields.
- Predefined ORR, OER, HER and HOR reactions plus a user-defined equilibrium potential.
- Automatic equilibrium-potential conversion to SHE, RHE and the selected reference electrode.
- Selectable potential interval, including **Use current plot range**.
- Analysis using current or current density.
- Linear regression of overpotential versus log10 absolute disk current/current density.
- Outputs: signed and absolute Tafel slope, intercept, R² and number of data points.
- Export to PNG, interactive HTML and Excel.
- Validation and automated tests for equilibrium potentials and Tafel regression.

## Scientific scope

The predefined thermodynamic and reference-electrode potentials are tabulated for 25 °C. For temperatures different from 25 °C, the pH conversion is temperature-corrected and the report contains a warning. The selected fit interval must represent the linear kinetic Tafel region; mass-transport-limited data are not suitable.
